nombre=int(input("Ingrese el nombre de cliente: "))
cantidad=int(input("Ingrese la cantidad de pantalon: "))
subtotal=int(input("Ingrese el costo de pantalon: "))
compradas=int(input("Ingrese el pantalon compradas: "))
mayor=int(input("Verificar el subtotal de a apagar de mayor: "))
if 10== 7:
    print("Cual es el subtotal de descuento")
else:
    Descuento= 7 * 10
    print("El descuento de pantalon.")
    Mensaje=(nombre)
    calcular,descuento = 25 * 10
    print("El resultado de descuento")
if 25== 10:
    print("Cual es el descuento.")
else:
    subtotal= 700 * 5
    print("Cual es el subtotal.")
    pagar= 5 * 700
    print("Cuantos debemos que a pagar.")
    Mensaje=(cantidad)














